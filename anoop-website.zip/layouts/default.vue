<template>
    <CommonHeader />
    <slot></slot>

    <CommonFooter />
</template>