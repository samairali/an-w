<template>
    <section id="OurMission">
        <div class="px-4 m-auto place-self-center text-center text-white  bg-gray-900 md:py-16 py-10">
            <h1 class="md:max-w-2xl mb-4 text-4xl font-extrabold tracking-tight leading-none md:text-4xl xl:text-4xl mx-auto">Our Mission to Help You Succeed</h1>
            <p class="md:max-w-2xl font-dark text-gray-500 md:text-lg lg:text-xl mx-auto mb-0 mt-5 ">We are a digital marketing agency in Canada that began by offering our clients practical solutions in digital marketing, which got them the results they expected from us. Our team consists of skilled people who are leaders in their fields. We provide the highest quality service; thus, we recognize the value of keeping up with the most recent digital marketing trends and technologies. We are devoted to assist companies in flourishing in the digital world. Contact us immediately to learn more about how we can assist you in achieving your business objectives.</p>
        </div>
    </section>
</template>