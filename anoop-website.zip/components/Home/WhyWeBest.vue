<template>
    <section class="bg-gray-900 border-b border-gray-200" id="HeroSection">
        <div class="grid max-w-screen-xl px-4 py-8 mx-auto lg:gap-8 xl:gap-4 lg:py-16 lg:grid-cols-12">
            <div class="mr-auto place-self-center lg:col-span-6">
                <p class=" text-white">Why Choose Us</p>
                <h1 class="max-w-2xl mb-4 text-4xl font-extrabold tracking-tight leading-none md:text-5xl xl:text-4xl  text-white">Why We are the Best to Choose?</h1>
                <p class="max-w-2xl mb-6 font-light text-gray-500 lg:mb-8 md:text-lg lg:text-xl  text-gray-400">We are always here to help you grow your company by providing you with cost-efficient and successful digital marketing strategies.</p>
                <p class="max-w-2xl mb-6 font-light text-gray-500 lg:mb-8 md:text-lg lg:text-xl  text-gray-400">We put a lot of effort into delivering better results and more visitors, which can help your business expand.</p>
                
            </div>
            <div class="hidden lg:mt-0 lg:col-span-6 lg:flex overflow-hidden" >
                <div class="grid grid-cols-1 gap-4">
                    <div class="relative bg-white  rounded-lg custom-box-shadow p-4 py-10 hover:bg-blue-800 hover:text-white" :data-aos="'fade-left'" data-aos-duration="1000">
                        <h3 class="text-3xl font-bold mb-5">100% Transparent</h3>
                        <p>As a digital marketing service provider, we value open communication with our clients. The final product of our results is always shared.</p>
                    </div>
                    <div class="relative bg-white   rounded-lg custom-box-shadow p-4 py-10 hover:bg-blue-800 hover:text-white" :data-aos="'fade-left'" data-aos-duration="1000">
                        <h3 class="text-3xl font-bold mb-5">Genuine Communication</h3>
                        <p>Not only do we communicate with you and explain the strategies of our digital marketing company in Canada, but we also make it simple for you to collaborate with us.</p>
                    </div>
                    <div class="relative  bg-white  rounded-lg custom-box-shadow p-4 py-10 hover:bg-blue-800 hover:text-white" :data-aos="'fade-left'" data-aos-duration="1000">
                        <h3 class="text-3xl font-bold mb-5">Results Focused</h3>
                        <p>We continuously monitor the results of our work for putting marketing first and make adjustments to make sure you get the best possible return on investment.</p>
                    </div>
                </div>
            </div>                
        </div>
    </section>
</template>