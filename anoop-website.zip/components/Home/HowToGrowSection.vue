<template>
    <section class="  " id="HowToGrowSection">
        <div class="grid max-w-screen-xl px-4 py-8 mx-auto lg:gap-8 xl:gap-0 lg:pb-16 lg:grid-cols-12 overflow-hidden">
            <div class="hidden lg:mt-0 lg:col-span-5 lg:flex overflow-hidden" >
                <img src="https://flowbite.s3.amazonaws.com/blocks/marketing-ui/hero/phone-mockup.png" alt="mockup" :data-aos="'fade-right'" data-aos-duration="1000">
            </div> 
            <div class="m-auto place-self-center lg:col-span-7 md:pl-10 overflow-hidden" :data-aos="'fade-left'" data-aos-duration="1000">
                <h1 class="max-w-2xl mb-4 text-4xl font-extrabold tracking-tight leading-none md:text-4xl xl:text-4xl ">How We Grow Your Business in Days</h1>
                <p class="max-w-2xl mb-6 font-dark text-gray-500 lg:mb-8 md:text-lg lg:text-xl ">Our digital marketing strategies are fantastic because it gives companies lots of chances to expand their business. The finest prospects for survival, competition, and even business expansion are offered by DigiGenius Company for business owners.</p>
                <h1 class="max-w-2xl mb-4 text-4xl font-extrabold tracking-tight leading-none md:text-4xl xl:text-2xl flex gap-4 items-center "><nuxt-icon name="chart" class="mt-2 rounded-xl bg-blue-800 w-10 h-10 items-center flex justify-center" /><span>Marketing Agency</span></h1>
                <p class="max-w-2xl mb-6 font-dark text-gray-500 lg:mb-8 md:text-lg lg:text-xl ">Our digital marketing strategies are fantastic because it gives companies lots of chances to expand their business. The finest prospects for survival, competition, and even business expansion are offered by DigiGenius Company for business owners.</p>
                <h1 class="max-w-2xl mb-4 text-4xl font-extrabold tracking-tight leading-none md:text-4xl xl:text-2xl flex gap-4 items-center"><nuxt-icon name="rocket" class="mt-2 rounded-xl bg-blue-800 w-10 h-10 items-center flex justify-center" /><span>SEO Services</span></h1>
                <p class="max-w-2xl mb-6 font-dark text-gray-500 lg:mb-8 md:text-lg lg:text-xl ">Our digital marketing strategies are fantastic because it gives companies lots of chances to expand their business. The finest prospects for survival, competition, and even business expansion are offered by DigiGenius Company for business owners.</p>
                
            </div>
                           
        </div>
    </section>
</template>
<style>
.nuxt-icon svg{
  color: #fff;
}
</style>