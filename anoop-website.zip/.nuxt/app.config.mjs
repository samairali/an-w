
import { defuFn } from 'C:/Users/ASUS/Desktop/anoop-website/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
